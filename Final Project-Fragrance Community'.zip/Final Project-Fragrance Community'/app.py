from flask import Flask, render_template, redirect, session, url_for, request, flash
from werkzeug.security import generate_password_hash, check_password_hash
import pandas as pd
from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin, login_user, login_required, logout_user, current_user, LoginManager
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField
from wtforms.validators import InputRequired, Length, ValidationError
from wtforms import StringField, PasswordField, SubmitField
from wtforms.widgets import TextArea
from flask_bcrypt import Bcrypt
from flask_admin import Admin
from flask_admin.contrib.sqla import ModelView
from datetime import datetime

app = Flask(__name__)
app.config['FLASK_ADMIN_SWATCH'] = 'cerulean'
admin = Admin(app, name='管理员', template_mode='bootstrap3')
app.config['SECRET_KEY'] = 'thisissecretkey'

db = SQLAlchemy(app)#create the database instance
bcrypt = Bcrypt(app)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///demoapp.db'#connect app files to database? Not sure

db = SQLAlchemy(app)
login_manager = LoginManager()
login_manager.init_app(app)

class User(db.Model):
    __tablename__ = 'users'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    username = db.Column(db.String(50),unique=True)
    email = db.Column(db.String(50),unique=True)
    password = db.Column(db.String(30))
    is_admin=db.Column(db.Integer)

    def __repr__(self):
        return '<User %r>' % self.id

admin.add_view(ModelView(User, db.session))

class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(15), unique=True)
    email = db.Column(db.String(50), unique=True)
    password = db.Column(db.String(80))
    bio = db.Column(db.Text)
    admin = db.Column(db.Boolean)
    notes = db.relationship('Note', backref='writer', lazy='dynamic')

class Todo(db.Model):
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    content = db.Column(db.String(200), nullable=False)
    date_expected = db.Column(db.DateTime, nullable=False)

    def __repr__(self):
        return '<Task %r>' % self.id


class Note(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(25))
    note_body = db.Column(db.String(100))
    note_writer = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    author = db.Column(db.String(255))
    date_created = db.Column(db.TIMESTAMP, default=datetime.utcnow, nullable=False)
    # date_created = db.Column(db.DateTime, default=datetime.utcnow)

class NewNoteForm(FlaskForm):
    title = StringField("Title", validators=[InputRequired(), Length(max=25)], render_kw={"placeholder": "Title"})
    ##note_body = TextAreaField("Note Body", validators=[InputRequired(), Length(max=100)], render_kw={"placeholder":  "Note Body"})
    note_body = StringField(u'Text', widget=TextArea())
    submit = SubmitField("Add Note")

class UpdateNoteForm(FlaskForm):
    title = StringField("Title", validators=[InputRequired(), Length(max=25)], render_kw={"placeholder": "Title"})
    ##note_body = TextAreaField("Note Body", validators=[InputRequired(), Length(max=100)], render_kw={"placeholder":  "Note Body"})
    note_body = StringField(u'Text', widget=TextArea())
    submit = SubmitField("Update Note")

class RegisterForm(FlaskForm):
    email = StringField("Email", validators=[InputRequired(), Length(max=50)], render_kw={"placeholder": "example@gmail.com"})
    username = StringField("Username", validators=[InputRequired(), Length(min=4, max=15)], render_kw={"placeholder": "Username"})
    password = PasswordField("Password", validators=[InputRequired(), Length(min=4, max=15)], render_kw={"placeholder": "********"})
    submit = SubmitField("Sign Up")

    def validate_username(self, username):
        existing_user_username = User.query.filter_by(username=username.data).first()
        if existing_user_username:
            raise ValidationError("That username already exists. Please choose a different one.")

    def validate_email(self, email):
        existing_user_email = User.query.filter_by(email=email.data).first()
        if existing_user_email:
            raise ValidationError("That email address belongs to different user. Please choose a different one.")

class LoginForm(FlaskForm):
    username = StringField("Username", validators=[InputRequired(), Length(max=15)], render_kw={"placeholder": "Username"})
    password = PasswordField("Password", validators=[InputRequired(), Length(max=50)], render_kw={"placeholder":  "Password"})
    submit = SubmitField("Login") 

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# WEB ROUTES FOR CONTROLLING ACCESS TO TEMPLATE VIEWS

@app.route("/")
def index():
    return render_template('index.html')

@app.route("/admin")
def admin():
    return render_template("admin/index.html")

@app.route("/blogs")
def blogs():
    df = pd.read_csv("shopping_info.csv")
    list = df.to_dict('records')
    return render_template('blogs.html',entries = list)



@app.route("/post")
def post():
    return render_template('post.html')

@app.route("/post2")
def post2():
    return render_template('post2.html')

@app.route("/video")
def video():
    return render_template('video.html')

@app.route("/video2")
def video2():
    return render_template('video2.html')

@app.route("/about")
@login_required
def about():
    return render_template('about.html')

@app.route("/shop")
@login_required
def shop():
    return render_template('shop.html')

####shop infomation######
@app.route("/shopinfo")
def shopinfo():
    return render_template('shopinfo.html')

@app.route("/shopinfo2")
def shopinfo2():
    return render_template('shopinfo2.html')

@app.route("/shopinfo3")
def shopinfo3():
    return render_template('shopinfo3.html')

@app.route("/shopinfo4")
def shopinfo4():
    return render_template('shopinfo4.html')

@app.route("/shopinfo5")
def shopinfo5():
    return render_template('shopinfo5.html')

@app.route("/shopinfo6")
def shopinfo6():
    return render_template('shopinfo6.html')

@app.route("/shopinfo7")
def shopinfo7():
    return render_template('shopinfo7.html')

@app.route("/shopinfo8")
def shopinfo8():
    return render_template('shopinfo8.html')

##########shop information########


########note###########
@app.route('/new-note', methods=['GET','POST'])
@login_required
def new_note():
    form = NewNoteForm()
    if form.validate_on_submit():
        new_note = Note(title=form.title.data, note_body=form.note_body.data, writer=current_user, author=current_user.username)
        db.session.add(new_note)
        db.session.commit()
        return redirect(url_for('view_notes'))
    return render_template('new_note.html', title='New Note', form=form)

@app.route('/my-notes', methods=['GET','POST'])
def view_notes():
    print('current user id:', current_user.id)
    if current_user.admin:
        # notes = Note.query.all()
        sqlalchemyObj = db.engine.execute('select note.id, note.title, note.note_body, note.date_created, user.username from note INNER JOIN user ON note.note_writer = user.id ORDER BY user.id')
    else:
        # dataset = Note.query.filter_by(writer=current_user).all()
        sql = 'select note.id, note.title, note.note_body, note.date_created, user.username from note INNER JOIN user ON note.note_writer = user.id WHERE note.note_writer == '+ str(current_user.id) + ' ORDER BY user.id'
        sqlalchemyObj = db.engine.execute(sql)
    notes = []
    for i in sqlalchemyObj:
        notes.append(i)
        # print(venues)
        dataset=[]
        dict={}
        for i in notes:
            dict['id'] = i[0]
            dict['title'] = i[1]
            dict['note_body'] = i[2]
            dict['date_created'] = i[3]
            dict['username'] = i[4]
            # print(i)
            # print(dict)
            dataset.append(dict.copy())
    print(dataset)
    return render_template('my_notes.html', notes=dataset, title='My Notes')

@app.route('/delete-note/<int:note_id>', methods=['GET',"POST"])
def delete_note(note_id):
    note = Note.query.get_or_404(note_id)
    db.session.delete(note)
    db.session.commit()
    return redirect(url_for('view_notes'))

@app.route('/update-note/<int:note_id>', methods=['GET',"POST"])
def update_note(note_id):
    form = UpdateNoteForm()
    note = Note.query.get_or_404(note_id)
    if request.method == 'GET':
        form.title.data = note.title
        form.note_body.data = note.note_body
    if form.validate_on_submit():  # request.method="POST"
            note.query.filter_by(id=note_id).first()
            if note:
                note.title = form.title.data
                note.note_body = form.note_body.data
                db.session.commit()
                print("Note id=",note_id)
                print("Updated.")
                return redirect(url_for("view_notes"))

    return render_template('update_note.html', form=form, title='Update Note', id=note_id)
########note##########



@app.route("/contact")
def contact():
    return render_template('contact.html')

@app.route("/dashboard")
@login_required
def dashboard():
    return render_template('dashboard.html')

@app.route("/discussion")
@login_required
def discussion():
    return render_template('discussion.html')

@app.route("/discussion2")
@login_required
def discussion2():
    return render_template('discussion2.html')

@app.route("/discussion3")
@login_required
def discussion3():
    return render_template('discussion3.html')

@app.route("/discussion4")
@login_required
def discussion4():
    return render_template('discussion4.html')

@app.route("/discussion5")
@login_required
def discussion5():
    return render_template('discussion5.html')

@app.route("/discussion6")
@login_required
def discussion6():
    return render_template('discussion6.html')

@app.route("/rating")
def rating():
    return render_template('rating.html')

@app.route("/rose")
def rose():
    return render_template('rose.html')

@app.route("/serge")
def serge():
    return render_template('serge.html')

@app.route("/zhongguofeng")
def zhongguofeng():
    return render_template('zhongguofeng.html')

@app.route("/tanxiang")
def tanxiang():
    return render_template('tanxiang.html')

@app.route('/login', methods=['GET','POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(username=form.username.data).first()
        if user:
            if bcrypt.check_password_hash(user.password, form.password.data):
                login_user(user)
                return redirect(url_for("index"))

        flash("User does not exist, or invalid username or password.")
    return render_template('login.html', title="Login", form=form)


@app.route('/register', methods=['GET','POST'])
def register():
    form = RegisterForm()
    if form.validate_on_submit():
        hashed_password = bcrypt.generate_password_hash(form.password.data)
        new_user = User(username=form.username.data, email=form.email.data, password=hashed_password,bio='',admin=0)
        db.session.add(new_user)
        db.session.commit()
        return redirect(url_for('login'))
    return render_template('register.html', title='Register', form=form)


@app.route('/logout', methods=["GET","POST"])
def logout():
    session.clear()
    logout_user()
    return redirect(url_for('login'))


if __name__ == "__main__":
    app.run(host="127.0.0.1",port=10000)
